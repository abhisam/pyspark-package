# Changes in findspark

## 1.2.0

- Add `findspark.add_jars`
- Preserve PYSPARK_PYTHON env, if specified

## 1.1.0

- Add `findspark.add_packages`


## 1.0.0

First release
